"use client"

import { Header } from "../frontend/src/components/Header"

export default function SyntheticV0PageForDeployment() {
  return <Header />
}