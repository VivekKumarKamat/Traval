import { Phone, MessageSquare } from "lucide-react"

export function Header() {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-600 p-2 rounded-lg">
              <MessageSquare className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">GydeXP</h1>
              <p className="text-sm text-gray-600">Travel Studio</p>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <div className="hidden sm:flex items-center space-x-2 text-sm text-gray-600">
              <Phone className="h-4 w-4" />
              <span>WhatsApp Integration Active</span>
            </div>

            <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" title="System Online"></div>
          </div>
        </div>
      </div>
    </header>
  )
}
