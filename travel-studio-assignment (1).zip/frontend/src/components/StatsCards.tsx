import { Clock, CheckCircle, MessageSquare, TrendingUp } from "lucide-react"

interface StatsCardsProps {
  totalRequests: number
  pendingRequests: number
}

export function StatsCards({ totalRequests, pendingRequests }: StatsCardsProps) {
  const completedRequests = totalRequests - pendingRequests
  const completionRate = totalRequests > 0 ? Math.round((completedRequests / totalRequests) * 100) : 0

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">Total Requests</p>
            <p className="text-3xl font-bold text-gray-900">{totalRequests}</p>
          </div>
          <div className="bg-blue-100 p-3 rounded-full">
            <MessageSquare className="h-6 w-6 text-blue-600" />
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">Pending</p>
            <p className="text-3xl font-bold text-orange-600">{pendingRequests}</p>
          </div>
          <div className="bg-orange-100 p-3 rounded-full">
            <Clock className="h-6 w-6 text-orange-600" />
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">Completed</p>
            <p className="text-3xl font-bold text-green-600">{completedRequests}</p>
          </div>
          <div className="bg-green-100 p-3 rounded-full">
            <CheckCircle className="h-6 w-6 text-green-600" />
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">Completion Rate</p>
            <p className="text-3xl font-bold text-blue-600">{completionRate}%</p>
          </div>
          <div className="bg-blue-100 p-3 rounded-full">
            <TrendingUp className="h-6 w-6 text-blue-600" />
          </div>
        </div>
      </div>
    </div>
  )
}
