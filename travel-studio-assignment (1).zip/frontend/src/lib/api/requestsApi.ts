const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001/api"

export interface Request {
  id: number
  guestPhone: string
  requestText: string
  createdAt: string
  status: string
}

export interface ApiResponse<T> {
  success: boolean
  message: string
  data: T
}

/**
 * API client for guest requests
 */
export const requestsApi = {
  /**
   * Get all requests from the backend
   */
  async getAllRequests(): Promise<ApiResponse<Request[]>> {
    try {
      const response = await fetch(`${API_BASE_URL}/requests`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()
      return data
    } catch (error) {
      console.error("Error fetching requests:", error)
      throw new Error("Failed to fetch requests")
    }
  },

  /**
   * Get only pending requests
   */
  async getPendingRequests(): Promise<ApiResponse<Request[]>> {
    try {
      const response = await fetch(`${API_BASE_URL}/requests/pending`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()
      return data
    } catch (error) {
      console.error("Error fetching pending requests:", error)
      throw new Error("Failed to fetch pending requests")
    }
  },

  /**
   * Create a new request (used by n8n.io workflow)
   */
  async createRequest(requestData: {
    guestPhone: string
    requestText: string
  }): Promise<ApiResponse<Request>> {
    try {
      const response = await fetch(`${API_BASE_URL}/requests`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestData),
      })

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }

      const data = await response.json()
      return data
    } catch (error) {
      console.error("Error creating request:", error)
      throw new Error("Failed to create request")
    }
  },
}
