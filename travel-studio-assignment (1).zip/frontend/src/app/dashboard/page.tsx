"use client"

import { useQuery } from "@tanstack/react-query"
import { requestsApi } from "@/lib/api/requestsApi"
import { RequestsTable } from "@/components/RequestsTable"
import { LoadingSpinner } from "@/components/LoadingSpinner"
import { ErrorMessage } from "@/components/ErrorMessage"
import { Header } from "@/components/Header"
import { StatsCards } from "@/components/StatsCards"

export default function DashboardPage() {
  const {
    data: requestsResponse,
    isLoading,
    error,
    refetch,
  } = useQuery({
    queryKey: ["requests"],
    queryFn: requestsApi.getAllRequests,
  })

  const requests = requestsResponse?.data || []
  const pendingRequests = requests.filter((req) => req.status === "pending")

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <LoadingSpinner />
        </main>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <ErrorMessage message="Failed to load guest requests" onRetry={() => refetch()} />
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Guest Requests Dashboard</h1>
          <p className="text-gray-600">Monitor and manage guest requests in real-time</p>
        </div>

        <StatsCards totalRequests={requests.length} pendingRequests={pendingRequests.length} />

        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">Recent Requests</h2>
          </div>

          <RequestsTable requests={requests} />
        </div>
      </main>
    </div>
  )
}
