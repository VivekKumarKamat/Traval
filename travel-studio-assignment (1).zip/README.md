# GydeXP Travel Studio - Guest Request Logging Workflow

A comprehensive WhatsApp-based guest request management system built for luxury hotels. This MVP enables guests to send requests via WhatsApp, which are automatically processed and displayed on a real-time dashboard.

## 🏗️ Architecture

- **Frontend**: Next.js 14 with TypeScript, TanStack Query, Tailwind CSS
- **Backend**: NestJS with TypeScript, Prisma ORM, PostgreSQL
- **Workflow**: n8n.io for WhatsApp Business API integration
- **Deployment**: Vercel (Frontend), Railway/Heroku (Backend)

## 🚀 Quick Start

### Prerequisites

- Node.js 18.x or higher
- PostgreSQL database
- WhatsApp Business API sandbox account
- n8n.io account (free tier)

### Backend Setup

1. **Clone and install dependencies**
\`\`\`bash
cd backend
npm install
\`\`\`

2. **Database setup**
\`\`\`bash
# Copy environment file
cp .env.example .env

# Update DATABASE_URL in .env file
# Example: postgresql://username:password@localhost:5432/travel_studio_db

# Generate Prisma client and push schema
npm run prisma:generate
npm run prisma:push
\`\`\`

3. **Start the backend server**
\`\`\`bash
npm run start:dev
\`\`\`

The backend will be available at `http://localhost:3001`

### Frontend Setup

1. **Install dependencies**
\`\`\`bash
cd frontend
npm install
\`\`\`

2. **Environment configuration**
\`\`\`bash
# Copy environment file
cp .env.local.example .env.local

# Update API URL if needed (default: http://localhost:3001/api)
\`\`\`

3. **Start the development server**
\`\`\`bash
npm run dev
\`\`\`

The dashboard will be available at `http://localhost:3000`

### n8n.io Workflow Setup

1. **Install n8n.io locally**
\`\`\`bash
npm install -g n8n
\`\`\`

2. **Start n8n.io**
\`\`\`bash
n8n start
\`\`\`

3. **Import workflow**
- Open n8n.io at `http://localhost:5678`
- Import the workflow from `workflow/request-workflow.json`
- Configure environment variables:
  - `WHATSAPP_ACCESS_TOKEN`: Your WhatsApp Business API token
  - `WHATSAPP_PHONE_NUMBER_ID`: Your WhatsApp Business phone number ID

4. **WhatsApp Business API Setup**
- Sign up for WhatsApp Business API sandbox
- Get your access token and phone number ID
- Configure webhook URL to point to your n8n.io webhook

## 📱 WhatsApp Integration

### Sandbox Setup

1. Visit [WhatsApp Business API Sandbox](https://developers.facebook.com/docs/whatsapp/cloud-api/get-started)
2. Create a test app and get your credentials
3. Configure webhook URL: `https://your-n8n-instance.app.n8n.cloud/webhook/whatsapp-guest-requests`
4. Test with the provided test phone number

### Message Flow

1. Guest sends WhatsApp message: "I need extra towels"
2. n8n.io receives webhook from WhatsApp
3. Workflow extracts phone number and message text
4. Data is sent to NestJS backend via POST /api/requests
5. Request is saved to PostgreSQL database
6. Confirmation message sent back to guest
7. Dashboard automatically updates with new request

## 🎯 API Endpoints

### Backend Endpoints

- `POST /api/requests` - Create new guest request
- `GET /api/requests` - Get all requests
- `GET /api/requests/pending` - Get pending requests only

### Example Request

\`\`\`bash
curl -X POST http://localhost:3001/api/requests \
  -H "Content-Type: application/json" \
  -d '{
    "guestPhone": "+1234567890",
    "requestText": "I need extra towels please"
  }'
\`\`\`

## 🚀 Deployment

### Frontend (Vercel)

1. **Connect GitHub repository to Vercel**
2. **Configure environment variables**:
   - `NEXT_PUBLIC_API_URL`: Your backend API URL
3. **Deploy**: Vercel will automatically deploy from your main branch

### Backend (Railway/Heroku)

1. **Create new app on Railway or Heroku**
2. **Configure environment variables**:
   - `DATABASE_URL`: PostgreSQL connection string
   - `FRONTEND_URL`: Your Vercel app URL
3. **Deploy**: Connect your GitHub repository

### n8n.io (Cloud)

1. **Sign up for n8n.io cloud** (free tier available)
2. **Import workflow** from `workflow/request-workflow.json`
3. **Configure environment variables** in n8n.io settings
4. **Update webhook URL** in WhatsApp Business API settings

## 🧪 Testing

### Manual Testing

1. **Test Backend API**:
\`\`\`bash
# Test create request
curl -X POST http://localhost:3001/api/requests \
  -H "Content-Type: application/json" \
  -d '{"guestPhone": "+1234567890", "requestText": "Test request"}'

# Test get requests
curl http://localhost:3001/api/requests
\`\`\`

2. **Test WhatsApp Integration**:
   - Send a message to your WhatsApp Business sandbox number
   - Check n8n.io execution log
   - Verify request appears in dashboard

3. **Test Dashboard**:
   - Open `http://localhost:3000/dashboard`
   - Verify requests are displayed
   - Check real-time updates

### Sample Test Data

\`\`\`json
{
  "guestPhone": "+1234567890",
  "requestText": "I need extra towels for room 205"
}
\`\`\`

## 📊 Features

### Current Features

- ✅ WhatsApp message processing
- ✅ Real-time request logging
- ✅ Dashboard with request display
- ✅ Mobile-responsive design
- ✅ Automatic confirmation messages
- ✅ Request status tracking

### Future Enhancements

- 🔄 Request status updates (pending → completed)
- 🔍 Advanced filtering and search
- 📊 Analytics and reporting
- 🔔 Real-time notifications
- 👥 Multi-hotel support
- 🌐 Multi-language support

## 🛠️ Tech Stack Details

### Frontend
- **Next.js 14**: React framework with App Router
- **TypeScript**: Type safety and better DX
- **TanStack Query**: Data fetching and caching
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Beautiful icons
- **date-fns**: Date formatting utilities

### Backend
- **NestJS**: Scalable Node.js framework
- **Prisma**: Modern database toolkit
- **PostgreSQL**: Reliable relational database
- **TypeScript**: Type safety across the stack
- **Class Validator**: Request validation

### Integration
- **n8n.io**: Workflow automation platform
- **WhatsApp Business API**: Official WhatsApp integration
- **Vercel**: Frontend deployment platform

## 🔧 Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Verify DATABASE_URL in .env file
   - Ensure PostgreSQL is running
   - Check database credentials

2. **WhatsApp Webhook Not Working**
   - Verify webhook URL in WhatsApp Business API settings
   - Check n8n.io workflow is active
   - Ensure proper environment variables are set

3. **Frontend Not Loading Data**
   - Check backend is running on correct port
   - Verify NEXT_PUBLIC_API_URL in .env.local
   - Check browser console for errors

4. **CORS Issues**
   - Verify FRONTEND_URL in backend .env file
   - Ensure frontend URL matches exactly

### Debug Commands

\`\`\`bash
# Check backend logs
cd backend && npm run start:dev

# Check database connection
cd backend && npm run prisma:studio

# Test API endpoints
curl http://localhost:3001/api/requests

# Check n8n.io logs
# Visit http://localhost:5678 and check executions
\`\`\`

## 📞 Support

For technical support or questions:
- Email: ajha@gydexp.com
- LinkedIn: Connect with Abhinav (Product Manager & Tech Lead)

## 📄 License

This project is part of the GydeXP Travel Studio MVP and is proprietary software.

---

**GydeXP Travel Studio** | Empowering Hospitality Through Technology
