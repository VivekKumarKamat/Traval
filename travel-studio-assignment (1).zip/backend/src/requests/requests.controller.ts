import { Controller, Get, Post, Body, HttpStatus, HttpException } from "@nestjs/common"
import type { RequestsService } from "./requests.service"
import type { CreateRequestDto } from "./dto/create-request.dto"

@Controller("requests")
export class RequestsController {
  constructor(private readonly requestsService: RequestsService) {}

  /**
   * POST /api/requests - Create a new guest request
   * Used by n8n.io workflow to save WhatsApp requests
   */
  @Post()
  async createRequest(@Body() createRequestDto: CreateRequestDto) {
    try {
      const request = await this.requestsService.createRequest(createRequestDto);
      return {
        success: true,
        message: 'Request created successfully',
        data: request,
      };
    } catch (error) {
      throw new HttpException(
        {
          success: false,
          message: error.message || 'Failed to create request',
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * GET /api/requests - Get all pending requests
   * Used by Next.js dashboard to display requests
   */
  @Get()
  async getRequests() {
    try {
      const requests = await this.requestsService.getAllRequests()
      return {
        success: true,
        message: "Requests retrieved successfully",
        data: requests,
      }
    } catch (error) {
      throw new HttpException(
        {
          success: false,
          message: error.message || "Failed to fetch requests",
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      )
    }
  }

  /**
   * GET /api/requests/pending - Get only pending requests
   */
  @Get("pending")
  async getPendingRequests() {
    try {
      const requests = await this.requestsService.getPendingRequests()
      return {
        success: true,
        message: "Pending requests retrieved successfully",
        data: requests,
      }
    } catch (error) {
      throw new HttpException(
        {
          success: false,
          message: error.message || "Failed to fetch pending requests",
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
      )
    }
  }
}
