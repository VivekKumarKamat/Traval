import { Injectable } from "@nestjs/common"
import type { PrismaService } from "../prisma/prisma.service"
import type { CreateRequestDto } from "./dto/create-request.dto"

@Injectable()
export class RequestsService {
  constructor(private prisma: PrismaService) {}

  /**
   * Create a new guest request
   * @param createRequestDto - Request data from guest
   * @returns Created request with ID
   */
  async createRequest(createRequestDto: CreateRequestDto) {
    try {
      const request = await this.prisma.requests.create({
        data: {
          guestPhone: createRequestDto.guestPhone,
          requestText: createRequestDto.requestText,
          status: "pending",
        },
      })

      console.log(`📝 New request created: ${request.id} from ${request.guestPhone}`)
      return request
    } catch (error) {
      console.error("Error creating request:", error)
      throw new Error("Failed to create request")
    }
  }

  /**
   * Get all pending requests
   * @returns Array of pending requests
   */
  async getPendingRequests() {
    try {
      const requests = await this.prisma.requests.findMany({
        where: {
          status: "pending",
        },
        orderBy: {
          createdAt: "desc",
        },
      })

      console.log(`📋 Retrieved ${requests.length} pending requests`)
      return requests
    } catch (error) {
      console.error("Error fetching requests:", error)
      throw new Error("Failed to fetch requests")
    }
  }

  /**
   * Get all requests (for dashboard)
   * @returns Array of all requests
   */
  async getAllRequests() {
    try {
      const requests = await this.prisma.requests.findMany({
        orderBy: {
          createdAt: "desc",
        },
      })

      return requests
    } catch (error) {
      console.error("Error fetching all requests:", error)
      throw new Error("Failed to fetch all requests")
    }
  }
}
